# 📦 Data Preparation Notes

This repository is configured to keep large MATLAB `.mat` files outside normal Git tracking. Use GitHub Releases, Zenodo, institutional storage, or Git LFS for large datasets.

## Required folder layout

Place the required data in the repository root using the following structure:

```text
Model of rainfall/
├── raindrop_positions_R_5.0_z_1000_model_1.mat
├── raindrop_positions_R_5.0_z_1000_model_2.mat
├── ...
├── raindrop_positions_R_12.5_z_1000_model_1.mat
├── ...

initialphoton/
├── initial_photons1.mat
├── initial_photons2.mat
├── ...

mie_data_wavelength_1064.mat
mie_data_wavelength_1550.mat
```

## Required variables

### Rainfall model files

Each rainfall model file should contain:

```matlab
common_particle_positions
```

This variable should store raindrop coordinates in columns corresponding to `x`, `y`, and `z`.

### Initial photon files

Each initial photon file should contain:

```matlab
initial_photon_positions
Phaseshift
```

### Mie scattering files

Each Mie data file should contain:

```matlab
phi
theta
P
Phaseshift
```

## Large-file recommendation

Do not commit large `.mat` files directly to GitHub. Recommended options are:

1. Upload large datasets to a permanent data repository such as Zenodo.
2. Add the dataset DOI or download link to the main `README.md`.
3. Use Git LFS only if the files must remain inside the GitHub repository.
