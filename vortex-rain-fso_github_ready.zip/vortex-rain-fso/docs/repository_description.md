# Repository Name and Description

## Recommended repository name

`vortex-rain-fso`

## Alternative names

- `lg-rain-fso`
- `rain-fso-vortex-beams`
- `vortex-beam-rain-model`

## Short repository description

MATLAB codes for physics-based Monte Carlo modeling of Laguerre-Gaussian vortex beam propagation in rainy free-space optical communication channels.

## 2–3 sentence GitHub description

This repository provides MATLAB simulation and analysis codes for modeling Laguerre-Gaussian vortex beam propagation through rainy free-space optical communication channels. The framework compares Geometrical Optics and Mie scattering to evaluate received photon count, signal-to-noise ratio, attenuation, and mode-dependent beam performance under rainfall. The codes support reproducible figure generation for the associated manuscript on structured-light FSO links in adverse weather.
